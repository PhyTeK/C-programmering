/*  Transport of Zn++ in groundwater un mill tailing impoundments       */
/*  P. Martinet November 2000                                           */
/*  Based on:                                                           */
/*  Demonstration module No. 4 for  TRANSIENT  by 	M. Kolar, 1995	*/
/* ====================================================================	*/

#if defined(unix) || defined(__CYGWIN32__)
#include "../transien.h"
#else
#include "..\transien.h"
#endif
	/*  >>>>>>>>>> READ the information in transient.h  <<<<<<<<<<  */

#define NEQNS	5

typedef double ROW[NEQNS];


/* Input parameters - for Grid and Model only:
   ------------------------------------------- 
   (All control parameters are handled in  transient.c) */

/* A. Grid parameters: */
static double
	L= 2.;
static int
	interv = 75;

/* B. Model parameters: */
static double
	DX = 0.0,
	DY = 0.0,
	aa = 0.05555555555555555,
	bb = 0.55555555555555555,
	cc = 1.8,
	dd = 0.05555555555555555,
	randInitAmpl = 0.001,
	cDiffMax = 0.01; /* max allowed (recommended) cDiffM */
static int
	randSeed = 731,
	          /* start with random perturbation above */
	Init = 0, /* zero morphogen concentrations;
	     = 1  -  the trivial steady state;
			 using randInitAmpl and randSeed in both cases */
	BC = 0; /* use standard flux=0 b.c.;
	   = 1; use full mass-balance equ for the half intervals at ends */
/* Other global variables: */
static double
	bd, New, bNew, cNew, bdNew, TcNew, h,
	dx, dy, dxNew, dyNew, TdxNew, TdyNew;
static ROW
	*XY, *XY_o;
static double
	*UB[NEQNS], *LB[NEQNS];


int get_neqns_etc(void)
/*===================*/
{
title = "                     TRANSIENT\n\
                Demonstration No. 4\n\
                    Brusselator";
time_units = "";
tEnd = 50.;
tOutInit = 0.1;
tStepInit = 1e-4;
nOutOTH = 1;
return NEQNS;
}


void generate_grid(void)
/*====================*/
{
nnodes = interv + 1;
h = L / (double)interv;
}


int INPT_model_param(int words, char *str1, char *str2)
/*===================================================*/
{
 if(0) ;  /* each INPT macro starts with 'else if' */

 INPT(d,interv)	INPT(le,L)

 INPT(le,DX)		INPT(le,DY)
 INPT(le,aa)		INPT(le,bb)
 INPT(le,cc)		INPT(le,dd)
 INPT(d,Init)	INPT(d,randSeed)
 INPT(le,randInitAmpl)	INPT(d,BC)
 INPT(le,cDiffMax)
 else   return 0;

 return 1;
}


void WRONG_model_param(void)
/*========================*/
/* Check some obvious bounds: */
{
WRONG(interv)	WRONG(L)

WRONG(aa)	WRONG(cc)
WRONGz(bb)	WRONGz(dd)
WRONG1(Init)  WRONG(randSeed)  WRONG(randInitAmpl)
WRONG1(BC)
WRONG(cDiffMax)
}


#ifndef RAND_MAX
#define RAND_MAX 32767
#define RAND_WARNING { PE"\nCheck also the definition of RAND_MAX\
 in %s\n", __FILE__); }
#else
#define RAND_WARNING
#endif

void Initialize(double ***LBp, double ***UBp, double *c_lin, double *c_o_lin)
/*=========================================================================*/
{
int j,k;
static double NoBound = 0., Lower[2];
double Max = randInitAmpl / RAND_MAX;

RAND_WARNING
srand(randSeed);

XY = (ROW *)c_lin;
XY_o = (ROW *)c_o_lin;

*LBp = LB;
*UBp = UB;

Lower[0] = 1.,  /* Bound type: constant */
Lower[1] = 0.;  /* Bound value */

for(j=0; j<NEQNS; j++) LB[j] = Lower; /* All lower bounds are identical */
for(j=0; j<NEQNS; j++) UB[j] = &NoBound;

if(Init) {
	for(j=0; j<nnodes; j++) {
		XY[j][0] = XY_o[j][0] = aa/dd + Max * rand();
		XY[j][1] = XY_o[j][1] = bb * dd / (cc * aa) + Max * rand();
	}
} else
		for(j=0; j<nnodes; j++)
	for(k=0; k<NEQNS; k++) XY[j][k] = XY_o[j][k] = Max * rand();

}


void read_profiles(char *filename)
/*==============================*/
{
PE"\nNo action in read_profiles() implemented\n");
PE"Initializations made in Initialize() unchanged\n\n");
}


/**************************/
/* XY[j][0] = X morphogen */
/* XY[j][1] = Y morphogen */
/**************************/


void auxiliary_parameters_for_evalf(void)
/*=====================================*/
{
New = 1. - Tau;

dx = DX / (h * h);
dy = DY / (h * h);
dxNew = dx * New;
dyNew = dy * New;
TdxNew = 2. * dxNew;
TdyNew = 2. * dyNew;
bd = bb + dd;
bNew = bb * New;
cNew = cc * New;
bdNew = bd * New;
TcNew = 2. * cNew;
}


void reaction_part(double *F, ROW *B, double *xy)
/*=============================================*/
{
 register double R;

  R = xy[0] * xy[0];
 F[1] = -(F[0] = cc * R * xy[1]);
 F[0] += aa - bd * xy[0];
 F[1] += bb * xy[0];
 B[1][1] = - (B[0][1] = cNew * R);
 R = xy[0] * xy[1] * TcNew;
 B[0][0] = R - bdNew;
 B[1][0] = bNew - R;
}


void evalf(int j, double *c_lin, double *F, double *A_lin,
 double *B_lin, double *D_lin, double *X_lin, double *Y_lin)
/*========================================================*/
{
/* Remember, that in the calling procedure, X=A and Y=D
   (i.e., X_lin=A_lin, Y_lin=D_lin). All elements of A, B, D
   (and thus X and Y) are set to zero in nl3band before evalf
   is called. Only their nonzero elements have to be set here. 
*/
static double *cBarM, *cBar0, *cBarP, B00, B11;
static ROW    VM, V0, VP, *xy, *A, *B, *D, *X, *Y;

if(j==0){

/* These assignments need actually be done only once, because
   runband always uses the same arguments in evalf */
xy = (ROW *)c_lin;
A = (ROW *)A_lin;
B = (ROW *)B_lin;
D = (ROW *)D_lin;
X = (ROW *)X_lin;
Y = (ROW *)Y_lin;

  /* Assume that the first call to evalf() is with j=0 and
     on each subsequent call j is increased by 1 (THIS IS NOT
     CHECKED HERE!).
     So first do some initializations needed later for j > 0:
  */
  { register i;
    for(i=0; i<NEQNS; i++) {
	V0[i] = Tau * XY_o[0][i] + New * xy[0][i];
	VP[i] = Tau * XY_o[1][i] + New * xy[1][i];
    }
  }
  cBarM = (double *)VM;
  cBar0 = (double *)V0;
  cBarP = (double *)VP;
  B00 = TdxNew + tStepInv;
  B11 = TdyNew + tStepInv;

  /* Now do the x=0 boundary conditions: */
  if(BC) {
   reaction_part(F, B, cBar0);
   F[0] += 2. * dx * (cBarP[0] - cBar0[0]);
   F[1] += 2. * dy * (cBarP[1] - cBar0[1]);
   /* time derivative: */
   F[0] += (XY_o[j][0] - xy[j][0]) * tStepInv;
   F[1] += (XY_o[j][1] - xy[j][1]) * tStepInv;
   B[0][0] -= B00;
   D[0][0] = TdxNew;
   B[1][1] -= B11;
   D[1][1] = TdyNew;
  } else {
   F[0] = -3. * xy[0][0] + 4. * xy[1][0] - xy[2][0];
   B[0][0] = -3.;
   D[0][0] = 4.;
   X[0][0] = -1.;
   F[1] = -3. * xy[0][1] + 4. * xy[1][1] - xy[2][1];
   B[1][1] = -3.;
   D[1][1] = 4.;
   X[1][1] = -1.;
  }

} else if(j<interv) { /* Internal nodes: */

 /* First update cBar's: */
 { double *p;
   register i;
   p = cBarM;
   cBarM = cBar0;
   cBar0 = cBarP;
   cBarP = p;
   for(i=0; i<NEQNS; i++)
	cBarP[i] = Tau * XY_o[j+1][i] + New * xy[j+1][i];
 }
   reaction_part(F, B, cBar0);
   F[0] += dx * (cBarM[0] - 2. * cBar0[0] + cBarP[0]);
   F[1] += dy * (cBarM[1] - 2. * cBar0[1] + cBarP[1]);
   /* time derivative: */
   F[0] += (XY_o[j][0] - xy[j][0]) * tStepInv;
   F[1] += (XY_o[j][1] - xy[j][1]) * tStepInv;
   A[0][0] = dxNew;
   B[0][0] -= B00;
   D[0][0] = dxNew;
   A[1][1] = dyNew;
   B[1][1] -= B11;
   D[1][1] = dyNew;

} else { /* j=interv:  x=L boundary conditions */

  if(BC) {
   /* Remember, cBar's were not updated here! */
   reaction_part(F, B, cBarP);
   F[0] += 2. * dx * (cBar0[0] - cBarP[0]);
   F[1] += 2. * dy * (cBar0[1] - cBarP[1]);
   /* time derivative: */
   F[0] += (XY_o[j][0] - xy[j][0]) * tStepInv;
   F[1] += (XY_o[j][1] - xy[j][1]) * tStepInv;
   A[0][0] = TdxNew;
   B[0][0] -= B00;
   A[1][1] = TdyNew;
   B[1][1] -= B11;
  } else {
   F[0] = 3. * xy[j][0] - 4. * xy[j-1][0] + xy[j-2][0];
   B[0][0] = 3.;
   A[0][0] = -4.;
   Y[0][0] = 1.;
   F[1] = 3. * xy[j][1] - 4. * xy[j-1][1] + xy[j-2][1];
   B[1][1] = 3.;
   A[1][1] = -4.;
   Y[1][1] = 1.;
  }

}

}


void pr_model(int explain)
/*======================*/
/* explain = 0  -  no explanation, just list the values of  input parameters
	     1  -  any explanation on input parameters invited
	    -1  -  no explanation required, all quantities calculated before
		   the beginning of integration (such as grid parameters)
		   are already available				*/
{
Pm"%c\n%c cDiffMax =   %g\n", CmntC, CmntC, cDiffMax);
if(explain > 0)
 Pm"   Maximum allowed/recommended change in c in a single time step at all times\n");
Pm"%c\n%cGrid:\n%c====\n",CmntC,CmntC,CmntC);
Pm"%c L =      %g\n",CmntC,L);
Pm"%c interv = %d (# of grid intervals in [0,L])\n",CmntC,interv);
if(explain < 0) Pm"%c x step = %g\n",CmntC,h);
Pm"%c\n%cModel parameters:\n",CmntC,CmntC);
Pm"%c================\n",CmntC);
Pm"%c DX = %g\n",CmntC,DX);
Pm"%c DY = %g\n",CmntC,DY);
Pm"%c aa = %g\n",CmntC,aa);
Pm"%c bb = %g\n",CmntC,bb);
Pm"%c cc = %g\n",CmntC,cc);
Pm"%c dd = %g\n",CmntC,dd);
Pm"%c randInitAmpl = %g\n",CmntC, randInitAmpl);
Pm"%c randSeed = %d\n",CmntC,randSeed);
Pm"%c Init = %d\n",CmntC,Init);
if(explain > 0) {
 Pm"   Init = 1: start near the trivial steady state\n");
 Pm"        = 0: start near zero morphogen concentrations\n");
 Pm"   In both cases, add random initial component using randInitAmpl, randSeed\n");
}
Pm"%c BC = %d\n",CmntC,BC);
if(explain > 0) {
 Pm"   BC = 0: use standard flux=0 b.c.\n");
 Pm"      = 1: use full mass-balance equ for the end half-intervals\n");
}
Fm
}

void pr_profiles(int MaxIter)
/*=========================*/
{
int j;
static count = 0; /* For steady=2, count enables to take different
         action below for steady state calculation proper and for the
         subsequent transient calculation */

if(steady && !count++) {
 PR"\n%c\t\tSteady State\n", CmntC);
 PR"%c No. of iterations done = %d\n",CmntC, MaxIter);
} else {
 PR"\n%c Time = %e\n", CmntC, t);
 PR"%c Last tStep = %e\n", CmntC, tStepLast);
 PR"%c Max. # of iterations done since last profile = %d\n",CmntC, MaxIter);
}
report_max_resid(out, CmntC);
PR"%c  x         [X]        [Y]\n", CmntC);
for(j= 0;j<nnodes;j++)
1	PR" %.8f  %e %e\n", j * h, XY_o[j][0], XY_o[j][1]);
(void)fflush(out);
}


void init_Other(void)
/*=================*/
{ }


int update_Other(void)
/*==================*/
{ return 0; }


void pr_Other(int only_Other)
/*=========================*/
{ }


double cDiffMaxf(double t)
/*======================*/
{
        return cDiffMax;
}
